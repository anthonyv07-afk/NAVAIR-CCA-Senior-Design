%X47B_SIZING_CHECK  Option B comparator check: SIZE an aircraft to the
%   X-47B's requirements and compare the result with the real X-47B.
%
%   x47b_validation.m checks the individual models on the fixed, real
%   airframe. This script checks the whole sizing LOOP: it gives
%   sizing_mainloop only what the X-47B had to do -- 4,500 lb internal
%   payload, one F100-PW-220U, carrier catapult/arrested-landing
%   constraints, and a ferry range -- and lets it choose TOGW and wing area.
%
%   The published X-47B range is uncertain (2,100-3,500 nm across sources),
%   so the loop is closed at several design ranges.
%
%   Inputs: x47b_sizing.json = x47b_validation.json with
%     spot_factor_max = 2.0  -- the X-47B was not designed to our RFP's 0.80
%                              deck-spot limit (its own spot factor is ~1.0),
%                              so the hard spot gate in sizing_mainloop is
%                              relaxed for this check only.
%
%   Run from the cca_sizing/ folder:  x47b_sizing_check

addpath(genpath(pwd));
json = 'x47b_sizing.json';

ranges_nm  = [2100 3000 3500];   % design ferry ranges to close at
plot_range = 3500;               % case drawn on the matching diagram
W_TO_guess = 40000;              % lb

pub.W_TO = 44500;  pub.S_ref = 953.6;  pub.b = 62.1;  pub.OEW = 14000;

opts.relax = 0.5;  opts.tol_rel = 1e-4;  opts.max_iter = 80;  opts.verbose = false;

R = struct('range',{},'W_TO',{},'OEW',{},'fuel',{},'cap',{},'S',{},'b',{}, ...
           'WS',{},'TW',{},'spot',{},'eng_ok',{},'n',{},'ok',{},'msg',{});
disc_plot = [];  res_plot = [];

for k = 1:numel(ranges_nm)
    % Fresh discipline objects for every case: geom/prop are handle objects
    % that the loop mutates (S_ref, thrust_scale).
    disc = cca_disciplines(json, W_TO_guess, 70, 'ferry');
    idx = find(arrayfun(@(s) strcmpi(string(s.type), "cruise"), disc.missions));
    for i = idx
        disc.missions(i).distance_nm = ranges_nm(k);
    end

    r.range = ranges_nm(k);
    try
        res = sizing_mainloop(disc.geom, disc.aero, disc.prop, disc.weights, ...
            disc.conditions, disc.missions, W_TO_guess, opts);
        p = res.final_pass;
        r.W_TO = res.W_TO;            r.OEW = p.OEW;
        r.fuel = p.W_fuel_total;      r.cap = p.fuel_capacity_lb;
        r.S = p.S_ref;                r.b = p.b;
        r.WS = p.WS_design;           r.TW = p.T_SL/res.W_TO;
        r.eng_ok = p.engine_ok;       r.n = res.n_iter;
        r.spot = p.spot_factor;
        if ranges_nm(k) == plot_range, disc_plot = disc; res_plot = res; end
        r.ok = true;                  r.msg = "";
    catch err
        [r.W_TO, r.OEW, r.fuel, r.cap, r.S, r.b, r.WS, r.TW, r.spot] = deal(NaN);
        r.eng_ok = false;  r.n = NaN;  r.ok = false;  r.msg = string(err.message);
    end
    R(end+1) = r; %#ok<SAGROW>
end

%% Results table
fprintf('\n=== Option B: sizing loop closed on X-47B requirements ===\n');
fprintf('  (4,500 lb payload, 1 x F100-PW-220U 16,000 lbf, tailless, carrier constraints)\n\n');
fprintf('%-22s', 'Quantity');
for k = 1:numel(R), fprintf('%12s', sprintf('%d nm', R(k).range)); end
fprintf('%12s\n', 'X-47B pub');
prow('W_TO [lb]',          [R.W_TO],        pub.W_TO,  '%12.0f');
prow('OEW [lb]',           [R.OEW],         pub.OEW,   '%12.0f');
prow('OEW / W_TO [-]',     [R.OEW]./[R.W_TO], pub.OEW/pub.W_TO, '%12.3f');
prow('Fuel loaded [lb]',   [R.fuel],        NaN,       '%12.0f');
prow('Fuel capacity [lb]', [R.cap],         NaN,       '%12.0f');
prow('S_ref [ft^2]',       [R.S],           pub.S_ref, '%12.1f');
prow('Span b [ft]',        [R.b],           pub.b,     '%12.1f');
prow('W/S [psf]',          [R.WS],          pub.W_TO/pub.S_ref, '%12.1f');
prow('T/W [-]',            [R.TW],          16000/pub.W_TO, '%12.3f');
prow('Spot factor [-]',    [R.spot],        pub.b*0.5*38.2/1180, '%12.3f');
prow('Iterations',         [R.n],           NaN,       '%12.0f');

fprintf('\n%-22s', 'Fuel fits in tanks?');
for k = 1:numel(R), fprintf('%12s', yesno(R(k).ok && R(k).fuel <= R(k).cap)); end
fprintf('\n%-22s', 'Engine meets constr.?');
for k = 1:numel(R), fprintf('%12s', yesno(R(k).eng_ok)); end
fprintf('\n');

fprintf('\n%% difference from published X-47B:\n');
for k = 1:numel(R)
    if ~R(k).ok
        fprintf('  %d nm: did not converge -- %s\n', R(k).range, R(k).msg);
        continue
    end
    fprintf('  %4d nm:  W_TO %+6.1f%%   S_ref %+6.1f%%   span %+6.1f%%   OEW %+6.1f%%\n', ...
        R(k).range, pct(R(k).W_TO, pub.W_TO), pct(R(k).S, pub.S_ref), ...
        pct(R(k).b, pub.b), pct(R(k).OEW, pub.OEW));
end
%% Matching diagram for the plot_range case
if ~isempty(disc_plot)
    plot_matching(disc_plot, res_plot, pub, plot_range);
else
    fprintf('\nNo converged %d nm case to plot.\n', plot_range);
end

fprintf('\nDone.\n');


%% ---------------------------------------------------------------------
function prow(label, vals, pubval, fmt)
    fprintf('%-22s', label);
    fprintf(fmt, vals);
    if isnan(pubval), fprintf('%12s\n', '-'); else, fprintf([fmt '\n'], pubval); end
end

function s = yesno(tf)
    if tf, s = 'yes'; else, s = 'NO'; end
end

function d = pct(pred, pub)
    d = 100*(pred - pub)/pub;
end


function plot_matching(disc, res, pub, range_nm)
%PLOT_MATCHING  T/W vs W/S matching diagram for the converged X-47B sizing
%   case, with the sized design point, the wing sized to hold the fuel, and
%   the real X-47B. Saves x47b_matching_<range>nm.png next to this script.
    geom = disc.geom;  prop = disc.prop;
    W_TO = res.W_TO;   p = res.final_pass;
    WS_vec = linspace(40, 140, 201);            % same W/S range as run_demo
    env = run_constraints(geom, disc.aero, prop, disc.conditions, WS_vec, false);

    % Wing that holds the loaded fuel at the same W_TO (code's own tank
    % equations, bisection on S_ref); S_ref is restored afterwards.
    S_sized = geom.S_ref;  lo = S_sized;  hi = 3*S_sized;
    for it = 1:60
        geom.S_ref = 0.5*(lo + hi);
        if geom.fuel_capacity_lb < p.W_fuel_total, lo = geom.S_ref; else, hi = geom.S_ref; end
    end
    S_fuel = 0.5*(lo + hi);  b_fuel = geom.b;  geom.S_ref = S_sized;
    fprintf('\nWing sized to hold %.0f lb fuel at W_TO = %.0f lb: S = %.1f ft^2, b = %.1f ft, W/S = %.1f psf\n', ...
        p.W_fuel_total, W_TO, S_fuel, b_fuel, W_TO/S_fuel);

    TW_avail = prop.T_SL / W_TO;
    names = string(env.names);
    WSv = env.WS_vec(:)';  cap = env.WS_max_landing;
    ytop = max(0.40, 1.15*TW_avail);

    fig = figure('Color', [0.96 0.96 0.96], 'Position', [100 100 1000 620]);  hold on;  box on;  grid on;
    feas = WSv <= cap;  xf = WSv(feas);  yf = min(env.TW_envelope(feas), ytop);
    yf = yf(:)';  yf(~isfinite(yf)) = ytop;
    hF = fill([xf fliplr(xf)], [yf, ytop*ones(size(xf))], [0.85 0.94 0.85], ...
        'EdgeColor', 'none', 'FaceAlpha', 0.6);
    cols = lines(numel(names));  hC = gobjects(0);  lab = strings(0);
    for i = 1:numel(names)
        y = env.TW_curves{i}(:)';
        if ~any(isfinite(y)), continue; end
        hC(end+1) = plot(WSv, y, 'LineWidth', 1.8, 'Color', cols(i,:)); %#ok<AGROW>
        lab(end+1) = pretty(names(i)); %#ok<AGROW>
    end
    hL = xline(cap, '--k', 'LineWidth', 1.5);
    hT = yline(TW_avail, ':', 'Color', [0.3 0.3 0.3], 'LineWidth', 1.5);
    hD = plot(p.WS_design, TW_avail, '*', 'MarkerSize', 14, 'LineWidth', 2, 'Color', 'r');
    hW = plot(W_TO/S_fuel, TW_avail, 'o', 'MarkerSize', 10, 'LineWidth', 2, 'MarkerEdgeColor', [0 0.45 0.74]);
    hX = plot(pub.W_TO/pub.S_ref, 16000/pub.W_TO, 'd', 'MarkerSize', 10, 'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'k');

    xlim([WSv(1) WSv(end)]);  ylim([0 ytop]);
    set(gca, 'FontSize', 11);
    xlabel('Wing loading, W/S [lbf/ft^2]', 'FontSize', 12);  ylabel('Thrust-to-weight, T/W (sea-level static)', 'FontSize', 12);
    title(sprintf('X-47B Comparator (%s nm) -- Matching Diagram', commas(range_nm)), 'FontWeight', 'bold');
    lg = legend([hC, hF, hL, hT, hD, hW, hX], [lab, "Feasible region", "Landing W/S cap", ...
        "F100 available T/W", "Design point (sized)", "Wing sized to hold fuel", "Real X-47B"], ...
        'Location', 'northoutside', 'NumColumns', 2);
    lg.FontSize = 10;
    hold off;
    out = sprintf('x47b_matching_%dnm.png', range_nm);
    exportgraphics(fig, out, 'Resolution', 200);
    fprintf('Matching diagram saved to %s\n', out);
end

function s = commas(n)
%COMMAS  Integer with thousands separators, e.g. 43468 -> "43,468".
    s = regexprep(sprintf('%d', n), '\d(?=(\d{3})+$)', '$0,');
end

function s = pretty(name)
%PRETTY  Report-friendly legend label for a constraint condition name.
    switch name
        case "cruise_30kft",              s = "Cruise, M 0.70, 30,000 ft";
        case "dash_M0p8_30kft_RFP",       s = "Dash, M 0.80, 30,000 ft";
        case "dash_M0p85_30kft_teamgoal", s = "Dash, M 0.85, 30,000 ft";
        case "dash_M0p8_SL_strike",       s = "Dash, M 0.80, sea level";
        case "climb_SL",                  s = "Climb, sea level";
        case "catapult_takeoff",          s = "Catapult launch";
        otherwise,                        s = strrep(name, "_", " ");
    end
end
